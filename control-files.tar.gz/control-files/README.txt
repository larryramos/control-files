##################################
Source by: Larry Ribeiro
Visit my website: www.larryribeiro.com
:-)
##################################
####################################
WHAT'S THIS SCRIPT FOR???
####################################
You can monitor the files on your website and be alerted if any modification was made without your knowledge.

As websites commonly have a large number of files, it's very tough keep track of each file, unless you have anything to help you.

This script reads a folder and calculates the hash for each file, on each run.

Then, it compares hash resulting files against last run. If anything changed, you will receive an e-mail and an alert file is creates on "alerts" folder.


####################################
USAGE INSTRUCTIONS
####################################
1. Open file control-files.sh

2. Modify the following lines:
	#Give the full path from folder you want to monitor
	FOLDER="/var/www" 
	
	#Give the e-mail address to appear in FROM field on e-mail message
	FROM_MAIL="joe@joe-web-site.com"

3. Give execution permissions to control-files.sh (chmod +x control-files.sh)

4. Execute script for the 1st time to create "control.db" file

5. Create a cron job to run the script as you wish!


