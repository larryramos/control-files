#!/bin/bash
#########################| | |
#CHANGE THE VALUES BELOW V V V
#Path to monitor
FOLDER="/var/www" 
#Source mail field (FROM)
FROM_MAIL="joe@joe-website.com"
#######################################

#######################################
#Other variables. You don't need to change
DIR="/control-files"
cd ~/${DIR}
DB="control.db"
DB_NEW="control-now.db"
DT=`date -u`
DT_FILE=`echo ${DT} | tr ' ' '_'`
DIF="control-dif-"${DT_FILE}".txt"
#######################################
#Check if first-time
if [ ! -f ${DB} ]; then
	echo "Creating 'control.db' file now..."
	for a in `find ${FOLDER}/*`; do
		if [ -f ${a} ]; then	
			sha256sum $a >> ${DB}
		fi
	done
	echo "DB created"
else
	for a in `find ${FOLDER}/*`; do
		if [ -f ${a} ]; then	
			sha256sum $a >> ${DB_NEW}
		fi
	done
	diff ${DB} ${DB_NEW} > ${DIF}
	if [ $? -ne 0 ]; then
		echo "Detected modification..."
		cat ${DIF}

		echo "Subject: FILE MODIFICATION ON YOUR SITE" > msg.txt
		echo "Data (UTC):"${DT} >> msg.txt
		echo "" >> msg.txt
		cat  ${DIF} >> msg.txt
		echo "---------------------------------------------------------------------------" >> msg.txt
		echo "-FULL FILE LIST-" >> msg.txt
		echo "---------------------------------------------------------------------------" >> msg.txt
		ls -la ${FOLDER}/* >> msg.txt
		for b in `cat mail-list.txt`; do
			echo "Sending mail to ${b}"
			cat msg.txt | sendmail -f ${FROM_MAIL} ${b}
		done
		mv ${DB_NEW} ${DB}
		mv msg.txt alerts/msg-${DT_FILE}.txt
		mv ${DIF} alerts
	else
		rm ${DB_NEW} ${DIF}
		echo "Nothing new!"
	fi
fi
